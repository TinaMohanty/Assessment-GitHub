package com.test.automation.uiAutomation.homePage;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.test.automation.uiAutomation.testBase.TestBase;
import com.test.automation.uiAutomation.uiActions.NewRepository;

public class TC003_VerifyReadMeFileCommit extends TestBase {
	
	public static final Logger log = Logger.getLogger(TC002_VerifyCreateRepository.class.getName());	

	NewRepository nwRepository;

	@DataProvider(name="Repository")
	public String[][] getTestData() {
		String[][] testRecords = getData("D:\\EclipseO2 Workspace\\uiAutomation\\src\\main\\java\\com\\test\\automation\\uiAutomation\\Data\\GitHubData.xlsx", "Repository");
		return testRecords;
		
	}
	
	@BeforeClass
	public void setUp() throws IOException {
     init();
     nwRepository = new NewRepository(driver);
	}
	
	@Test(dataProvider="Repository")
	public void verifyLoginWithDifferentRecords(String repositoryName, String runMode) {
		
		if(runMode.equalsIgnoreCase("n")){
			throw new SkipException("user marked this record as no run");
		}
			log.info("============= Strting VerifyLoginWithDifferentRecords Test===========");
	
			nwRepository.commitReadMe();
			Assert.assertEquals(true, nwRepository.getReadmeSuccess());

}

}
