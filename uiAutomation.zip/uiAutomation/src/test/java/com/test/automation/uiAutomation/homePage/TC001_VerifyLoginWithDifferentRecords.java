package com.test.automation.uiAutomation.homePage;

import java.io.IOException;

import org.apache.log4j.Logger;
import org.testng.Assert;
import org.testng.SkipException;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.test.automation.uiAutomation.testBase.TestBase;
import com.test.automation.uiAutomation.uiActions.HomePage;


public class TC001_VerifyLoginWithDifferentRecords extends TestBase {
	
	
	public static final Logger log = Logger.getLogger(TC001_VerifyLoginWithDifferentRecords.class.getName());	

	HomePage hmpage;

	@DataProvider(name="LoginData")
	public String[][] getTestData() {
		String[][] testRecords = getData("D:\\EclipseO2 Workspace\\uiAutomation\\src\\main\\java\\com\\test\\automation\\uiAutomation\\Data\\GitHubData.xlsx", "LoginTestData");
		return testRecords;
		
	}
	

	@BeforeClass
	public void setUp() throws IOException {
     init();
     hmpage = new HomePage(driver);
	}

	@Test(dataProvider="LoginData")
	public void verifyLoginWithDifferentRecords(String userName, String Password, String runMode) {
		hmpage = new HomePage(driver);
		if(runMode.equalsIgnoreCase("n")){
			throw new SkipException("user marked this record as no run");
		}
		try {
			log.info("============= Strting VerifyLoginWithDifferentRecords Test===========");
	
			hmpage.loginToSite(userName, Password);
			boolean status = hmpage.verifyUserIconDisplay();
			
			if(status){
				
				hmpage.clickOnLogOut();
				Assert.assertEquals(status, true);
			}
			else {
				Assert.assertEquals(hmpage.getInvalidLoginText(), "Je account is nog niet geactiveerd :( Klik in de email op 'activeer'. Geen email gehad? Stuur opnieuw");
			}
			log.info("============= Finished VerifyLoginWithDifferentRecords Test===========");
			getScreenShot("verifyLoginWithDifferentRecords");
		} catch (Exception e) {
			
			getScreenShot("verifyLoginWithDifferentRecords");
		}
	}


}
