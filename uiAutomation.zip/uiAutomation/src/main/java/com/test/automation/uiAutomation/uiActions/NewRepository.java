package com.test.automation.uiAutomation.uiActions;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.test.automation.uiAutomation.testBase.TestBase;

public class NewRepository extends TestBase {
	
	public static final Logger log = Logger.getLogger(NewRepository.class.getName());
	
	
	WebDriver driver;
	
	@FindBy(xpath = ".//*[@id='dashboard']/div[1]/div/div[1]/h3/a")
	WebElement newRepository;
	
	@FindBy(id = "repository_name")
	WebElement repositoryName;
	
	@FindBy(id = ".//*[@id='new_repository']/div[3]/button")
	WebElement createRepository;
	
	@FindBy(xpath = ".//*[@id='js-repo-pjax-container']/div[2]/div[1]/div[1]/div[1]/p/a[1]")
	WebElement readme;
	
	@FindBy(id = "commit-summary-input")
	WebElement createReadme;
	
	@FindBy(id = "commit-description-textarea")
	WebElement readmeDescription;
	
	@FindBy(xpath = "submit-file")
	WebElement commitBtn;
	
	@FindBy(xpath = ".//*[@id='readme']/h3")
	WebElement commitReadme;
	
	public NewRepository(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	public void createRepository(String RepositoryName) {
		newRepository.click();
		log.info("cliked on new repository and object is:-"+newRepository.toString());
		repositoryName.click();
		repositoryName.sendKeys(RepositoryName);
		createRepository.click();
		
	}
	public void commitReadMe() {
		readme.click();
		createReadme.click();
		createReadme.sendKeys("QA Test");
		readmeDescription.click();
		readmeDescription.sendKeys("ReadMe Description");
		commitBtn.click();
	}
	
	public boolean getReadmeSuccess() {
		try {
 			commitReadme.isDisplayed();
 			return true;
 		} catch (Exception e) {
 		   return false;
 		}
	}


}
