package com.test.automation.uiAutomation.uiActions;

import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.test.automation.uiAutomation.testBase.TestBase;

public class HomePage extends TestBase {
	
	
	public static final Logger log = Logger.getLogger(HomePage.class.getName());
	
	WebDriver driver;
	Actions action;
	
	@FindBy(id = "user[login]")
	WebElement userName;
	
	@FindBy(id = "user[password]")
	WebElement Password;

	@FindBy(xpath = "html/body/div[1]/header/div/div[2]/div/span/div/a[1]")
	WebElement signIn;
	
	@FindBy(xpath = ".//*[@id='login']/form/div[3]/input[3]")
	WebElement signInBtn;
	
	@FindBy(id = "user-links")
	WebElement userLink;
	
	@FindBy(xpath = ".//*[@id='js-flash-container']/div")
	WebElement signInErr;
	
	
	
	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		action = new Actions(driver);
	}

     
     public void loginToSite(String emailAddress, String password){
    	 signIn.click();
 		log.info("cliked on sign in and object is:-"+signIn.toString());
 		userName.sendKeys(emailAddress);
 		log.info("entered email address:-"+emailAddress+" and object is "+userName.toString());
 		Password.sendKeys(password);
 		log.info("entered password:-"+password+" and object is "+Password.toString());
 		signInBtn.click();
 		log.info("clicked on submit butto and object is:-"+signInBtn.toString());
 	}
    
     
     public String getInvalidLoginText(){
 		log.info("erorr message is:-"+signInErr.getText());
 		userName.clear();
 		Password.clear();
 		return signInErr.getText();
 	}
     
     
     public boolean verifyUserIconDisplay(){
 		try {
            userLink.isDisplayed();
 			log.info("User Icon is dispalyed and object is:-"+userLink.toString());
 			return true;
 		} catch (Exception e) {
 			return false;
 		}
 	}
     
     public void clickOnLogOut() {
    	 driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
    	userLink.click();
    	 driver.findElement(By.xpath(".//*[@id='user-links']/li[3]/details/ul/li[9]/form/button")).click();
     }

}
