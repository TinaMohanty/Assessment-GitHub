package com.test.automation.uiAutomation.testBase;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.lang.reflect.Method;
import java.util.Calendar;
import java.util.concurrent.TimeUnit;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.io.FileHandler;
import org.testng.ITestResult;
import org.testng.Reporter;
import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
import com.test.automation.uiAutomation.ExcelReader.Excel_Reader;
import com.test.automation.uiAutomation.customListener.Listener;
//import com.test.automation.uiAutomation.homePage.Method;
import com.test.automation.uiAutomation.uiActions.HomePage;

public class TestBase {
	
	public static final Logger log = Logger.getLogger(TestBase.class.getName());
	
	
	public static WebDriver driver;
	String url = "https://github.com/";
	String browser = "chrome";
	public static ExtentReports extent;
	public static ExtentTest test;
	Excel_Reader excel;
	Listener lis;
	
	
	public void init() {
		
		extent = new ExtentReports(System.getProperty("user.dir")+"\\src\\main\\java\\com\\test\\automation\\uiAutomation\\report\\test.html", false);
		selectBrowser(browser);
		getUrl(url);
		String log4jConfpath = "log4j.properties";
		PropertyConfigurator.configure(log4jConfpath);
	}
	
	public void selectBrowser(String browser) {
		
		if(browser.equalsIgnoreCase("firefox")) {
			System.setProperty("webdriver.gecko.driver", System.getProperty("user.dir")+"/Drivers/geckodriver.exe");
			log.info("Creating object for Browser "+browser);
			driver = new FirefoxDriver();
			log.info("Creating object for Browser "+browser);
		}else if(browser.equalsIgnoreCase("chrome")) {
			System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/Drivers/chromedriver.exe");
			log.info("Creating object for Browser "+browser);
			driver = new ChromeDriver();
			log.info("Creating object for Browser "+browser);
		}
	}
	
	public void getUrl(String url) {
		log.info("Navigating to url "+url);
		driver.get(url);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	}
	
	public String[][] getData(String ExcelName, String sheetName) {
		//String path = System.getProperty("user.dir")+"src\\main\\java\\com\\test\\automation\\uiAutomation\\Data\\"+ExcelName;
		String path = ExcelName;
		excel = new Excel_Reader(path);
		String[][] data = excel.getDataFromSheet(sheetName, ExcelName);
		return data;
	}
	
	public void getScreenShot(String name) {
		
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");
		
		File srcFile = ((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		try {
			String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath()+"\\src\\main\\java\\com\\test\\automation\\uiAutomation\\screenshot\\";
			File destFile = new File((String)reportDirectory+name+"-"+formater.format(calendar.getTime())+".png");
			//FileUtils.copyFile(srcFile, destFile);
			FileHandler.copy(srcFile, destFile);
			
			//This will help us to link the Screenshot in testNG report.
			Reporter.log("<a href='" + destFile.getAbsolutePath() + "'> <img src='" + destFile.getAbsolutePath() + "' height='100' width='100'/> </a>");
			
		}catch(IOException e) {
			e.printStackTrace();
		}
	}
	
	public String captureScreen(String fileName) {
		if (fileName == "") {
			fileName = "blank";
		}
		File destFile = null;
		Calendar calendar = Calendar.getInstance();
		SimpleDateFormat formater = new SimpleDateFormat("dd_MM_yyyy_hh_mm_ss");

		File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);

		try {
			String reportDirectory = new File(System.getProperty("user.dir")).getAbsolutePath() + "/src/main/java/com/test/automation/uiAutomation/screenshot/";
			destFile = new File((String) reportDirectory + fileName + "_" + formater.format(calendar.getTime()) + ".png");
			FileHandler.copy(scrFile, destFile);
			// This will help us to link the screen shot in testNG report
			Reporter.log("<a href='" + destFile.getAbsolutePath() + "'> <img src='" + destFile.getAbsolutePath() + "' height='100' width='100'/> </a>");
		} catch (IOException e) {
			e.printStackTrace();
		}
		return destFile.toString();
	}
	
	
	public void getresult(ITestResult result) {
		if (result.getStatus() == ITestResult.SUCCESS) {
			test.log(LogStatus.PASS, result.getName() + " test is pass");
		} else if (result.getStatus() == ITestResult.SKIP) {
			test.log(LogStatus.SKIP, result.getName() + " test is skipped and skip reason is:-" + result.getThrowable());
		} else if (result.getStatus() == ITestResult.FAILURE) {
			test.log(LogStatus.ERROR, result.getName() + " test is failed" + result.getThrowable());
			String screen = captureScreen("");
			test.log(LogStatus.FAIL, test.addScreenCapture(screen));
		} else if (result.getStatus() == ITestResult.STARTED) {
			test.log(LogStatus.INFO, result.getName() + " test is started");
		}
	}
	
	


	
	@AfterMethod()
	public void afterMethod(ITestResult result) {
		getresult(result);
	}

	@BeforeMethod()
	public void beforeMethod(Method result) {
		test = extent.startTest(result.getName());
		test.log(LogStatus.INFO, result.getName() + " test Started");
	}

	@AfterClass(alwaysRun = true)
	public void endTest() {
		closeBrowser();
	}

	public void closeBrowser() {
		//driver.quit();
		log.info("browser closed");
		extent.endTest(test);
		extent.flush();
	}


	

}
